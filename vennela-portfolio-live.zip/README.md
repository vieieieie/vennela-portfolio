# 🎬 Vennela — Professional Video Editor Portfolio

A cinematic, dark-to-blue portfolio website created for **Vennela**, Video Editor. Built strictly adhering to your hand-drawn wireframe layout, featuring a two-column hero with framed portrait and direct contact buttons, smooth parallax scrolling, three dedicated category views, an embedded video lightbox player, and a fully centralized editable content system.

---

## 🌟 Key Features & Layout Architecture

### 1. Wireframe Hero Screen
- **Top Navigation**: Exactly three functional, smooth-scrolling links:
  - `About Me` &rarr; Scrolls directly to About Me section.
  - `My Work` &rarr; Scrolls directly to the 3 Portfolio Categories.
  - `Contact Me` &rarr; Scrolls directly to the Contact section.
- **Two-Column Hero**:
  - **Left Column**: Large, framed rectangular portrait of Vennela (`assets/vennela-photo.jpg`) with subtle cinematic border glow.
  - **Directly Under Picture**: Two working contact buttons:
    1. **Email Me** &rarr; Opens visitor's default email client (`mailto:vvennelaaa@gmail.com`).
    2. **Instagram** &rarr; Opens your Instagram profile (`https://instagram.com/vvennelaaa`) in a new browser tab.
  - **Right Column**: Prominent typography:
    - **Vennela**
    - **Video Editor**
    - Polished introductory biography highlighting pacing, storytelling, visual consistency, and audience retention.

### 2. Cinematic Parallax Scrolling
- Multi-layered depth transition from Hero into Portfolio.
- Ambient midnight blue glows, subtle cinematic grid, and editorial typography that move at differential speeds as you scroll.
- Respects `prefers-reduced-motion` for users with motion sensitivity.

### 3. The Portfolio Categories
Displayed in two prominent cards in a horizontal row on desktop and responsive stacking on mobile:
1. **Short-Form Content**: Fast-paced edits for Reels, Shorts, and other vertical social content.
2. **Long-Form Content**: Thoughtful long-form edits with strong pacing, structure, and narrative flow.

### 4. Dedicated Category Views & Lightbox Video Player
- Clicking any category card opens its dedicated category view.
- Includes a **"&larr; Back to All Categories"** button and **Category Switcher Tabs** to quickly jump between formats.
- Projects are presented in responsive grids:
  - **9:16 vertical cards** for Short-Form Content (Reels & Shorts).
  - **16:9 widescreen cards** for Long-Form Cinema.
- Clicking any project opens the **Cinematic Video Lightbox Modal** with playable video, title, platform badge, description, and external platform link.
- Pressing `Esc` or clicking outside closes the video modal and stops playback immediately.

### 5. Contact Me Section
- Deep midnight-blue background with subtle glowing accents.
- Exact headline copy:
  - *"Have a project in mind?"*
  - *"Let’s create something worth watching."*
- Dual action buttons for **Email Me** and **Instagram**, sharing the same centralized contact details as the hero buttons.
- Clean footer with copyright and back-to-top navigation.

---

## ⚡ How to Add, Edit, or Remove Portfolio Projects

All content on the website is centralized in a single file:  
📂 **[`js/portfolio-data.js`](file:///C:/Users/Harshita/.gemini/antigravity/scratch/video-editor-portfolio/js/portfolio-data.js)**

You **do not** need to edit any HTML or CSS to add or remove projects!

### Adding a New Project
Open `js/portfolio-data.js` and locate the `projects` array. Simply add a new project entry:

```javascript
{
  id: "my-new-project-01",
  category: "short-form", // Use: "short-form" or "long-form"
  title: "High-Energy Travel Reel",
  platform: "Instagram Reel", // "Instagram Reel", "YouTube Short", "Short Film", etc.
  aspectRatio: "9:16", // "9:16" for vertical, "16:9" for horizontal
  videoUrl: "https://www.instagram.com/reel/YOUR_REEL_ID/",
  embedUrl: "https://www.instagram.com/reel/YOUR_REEL_ID/embed",
  thumbnail: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=600&q=80",
  description: "Dynamic transition edit synchronized to upbeat audio beats.",
  tags: ["Travel", "Beat Sync", "Sound Design"],
  featured: true
}
```

### Video URL Guide:
- **YouTube Standard (16:9)**:
  - `videoUrl`: `https://www.youtube.com/watch?v=VIDEO_ID`
  - `embedUrl`: `https://www.youtube-nocookie.com/embed/VIDEO_ID`
  - `thumbnail`: `https://img.youtube.com/vi/VIDEO_ID/maxresdefault.jpg`
- **YouTube Shorts (9:16)**:
  - `videoUrl`: `https://youtube.com/shorts/VIDEO_ID`
  - `embedUrl`: `https://www.youtube-nocookie.com/embed/VIDEO_ID`
  - `thumbnail`: `https://img.youtube.com/vi/VIDEO_ID/hqdefault.jpg`
- **Instagram Reels**:
  - `videoUrl`: `https://www.instagram.com/reel/REEL_ID/`
  - `embedUrl`: `https://www.instagram.com/reel/REEL_ID/embed`

Whenever you add or modify a project in `portfolio-data.js`, the project count and the category view will update automatically.

---

## ✏️ How to Update Personal Information & Contact Links

Open [`js/portfolio-data.js`](file:///C:/Users/Harshita/.gemini/antigravity/scratch/video-editor-portfolio/js/portfolio-data.js) and look at the `personal` section:

```javascript
personal: {
  name: "Vennela",
  title: "Video Editor",
  subtitle: "Visual Storyteller & Post-Production Creative",
  bio: "I’m Vennela, a video editor passionate about transforming raw footage into engaging visual stories...",
  profileImage: "assets/vennela-photo.jpg",
  email: "vvennelaaa@gmail.com",
  instagramUrl: "https://instagram.com/vvennelaaa",
  instagramHandle: "@vvennelaaa",
}
```

- **To update your email**: Change `"vvennelaaa@gmail.com"`. Both the Hero button and Contact Me button will update automatically.
- **To update your Instagram**: Change `"https://instagram.com/vvennelaaa"`. Both buttons will link to your new profile.
- **To replace your photo**: Replace the file at `assets/vennela-photo.jpg` (or change the path in `portfolio-data.js`).

---

## 🔤 Custom Expressive Fonts (Birds of Paradise & Relationship of Melodrama)

The website is configured with `@font-face` rules for:
1. **Birds of Paradise**: Expressive script accent font.
2. **Relationship of Melodrama**: Expressive editorial display font.

If you have `.ttf` or `.woff2` font files for these fonts:
1. Place them inside the `assets/fonts/` folder:
   - `assets/fonts/Birds-of-Paradise.ttf`
   - `assets/fonts/Relationship-of-Melodrama.ttf`
2. The website will automatically use them!
3. If the files are not present, high-quality Google Fonts and system cursive/serif fallbacks (`Pinyon Script`, `Alex Brush`, `Playfair Display`, `Cinzel Decorative`) are automatically applied.

---

## 🚀 How to Preview & Test Locally

### Option 1: Direct File Opening
Double-click [`index.html`](file:///C:/Users/Harshita/.gemini/antigravity/scratch/video-editor-portfolio/index.html) in your file explorer. It will open in Google Chrome, Microsoft Edge, Safari, or Firefox with zero setup required.

### Option 2: Local HTTP Server (Python)
In PowerShell inside this project folder:
```powershell
python -m http.server 3000
```
Open your browser and visit: `http://localhost:3000`

---

## 🌐 Free 1-Click Publishing

### Netlify Drop (Fastest, ~30 seconds)
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag and drop the `video-editor-portfolio` folder directly into the browser window.
3. Your portfolio goes live instantly with an HTTPS web link!

### GitHub Pages
1. Push this folder to a GitHub repository.
2. In GitHub settings, go to **Pages** &rarr; select **main** branch &rarr; **Save**.
3. Your site will be published at `https://<your-username>.github.io/<repo-name>`.
