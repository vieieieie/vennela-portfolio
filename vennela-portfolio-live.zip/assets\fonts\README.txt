CUSTOM FONTS DIRECTORY
=======================

To use the exact display fonts requested:
1. Birds of Paradise:
   Save your font file here as:
   - Birds-of-Paradise.ttf
   or
   - Birds-of-Paradise.woff2

2. Relationship of Melodrama:
   Save your font file here as:
   - Relationship-of-Melodrama.ttf
   or
   - Relationship-of-Melodrama.woff2

When these files are present, css/style.css will automatically load and apply them to the headings and accents!
In the meantime, the site automatically falls back to elegant Google Fonts (Pinyon Script & Playfair Display / Cinzel Decorative).
